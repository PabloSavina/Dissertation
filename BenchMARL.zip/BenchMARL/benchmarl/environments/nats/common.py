# flake8: noqa

import copy

from typing import Callable, Dict, List, Optional

from torchrl.envs import EnvBase, PettingZooWrapper
from torchrl.data import CompositeSpec

from benchmarl.environments.common import Task, TaskClass
from benchmarl.utils import DEVICE_TYPING

from pettingzoo import ParallelEnv

from magpie.envs import SectorIEnv

import json

class NATSPZEnv(ParallelEnv):
    
    metadata = {"render_modes": ["human", "rgb_array"], "version": "NATSPZEnv_v0"}

    def __init__(self, num_envs=1):
        super(NATSPZEnv, self).__init__()

        with open(r"C:\Users\lenovo\OneDrive\Escritorio\code\magpie\sector_i.json", "r") as fp: config = json.load(fp)
        self.base_env = SectorIEnv(render_mode="rgb_array", **config)

        self.t = 1

        self.possible_agents = ["AIR0", "AIR1"]

        self.agent_name_mapping = dict(
            zip(self.possible_agents, list(range(len(self.possible_agents))))
        )

        self.render_mode = None


    def observation_space(self, agent):
        return self.base_env.observation_space

    def action_space(self, agent):
        return self.base_env.action_space

    def close(self):
        pass

    def render(self):
        return self.base_env.render()

    def reset(self, seed=None, options=None):
        self.t = 1
        self.agents = self.possible_agents[:]

        observations, infos = self.base_env.reset()

        actions = {
            callsign: self.base_env.action_space.sample() for callsign, observation in observations.items()
        }

        observations, rewards, dones, truncated, infos = self.base_env.step(actions)

        self.state = observations

        infos = {agent: {} for agent in self.agents}

        # print("RESET DONE")

        return observations, infos

    def step(self, actions):
        # self.t += 1
        env_truncation = self.t > 100

        # print(f"step, t: {self.t}")
        # print(f"env_truncation: {env_truncation}")
        # print()

        self.done = env_truncation

        if not actions:
            self.agents = []
            return {}, {}, {}, {}, {}

        observations, rewards, dones, truncated, infos = self.base_env.step(actions)

        if list(observations.keys()) == ['AIR0']:
            self.agents = ['AIR0']
            # print("hi")
        elif list(observations.keys()) == ['AIR1']:
            self.agents = ['AIR1']
            # print("hi")
        elif list(observations.keys()) == []:
            self.agents = []

        terminations = {agent: env_truncation for agent in self.agents}
        truncations = {agent: env_truncation for agent in self.agents}

        self.state = observations

        infos = {agent: {} for agent in self.agents}

        if env_truncation:
            self.agents = []

        return observations, rewards, terminations, truncations, infos

class NATSTask(Task):
    TEST = None

    @staticmethod
    def associated_class():
        return NATSClass

class NATSClass(TaskClass):
    def get_env_fun(
        self,
        num_envs: int,
        continuous_actions: bool,
        seed: Optional[int],
        device: DEVICE_TYPING,
    ) -> Callable[[], EnvBase]:
        config = copy.deepcopy(self.config)
        return lambda: PettingZooWrapper(
            NATSPZEnv(),
            seed=seed,
            device=device,
            categorical_actions=True,  # If your env has discrete actions, they need to be categorical (TorchRL can help with this)
            return_state=False,
            use_mask=True,
            **config,  # Pass the loaded config (this is what is in your yaml)
        )
    
    def supports_continuous_actions(self) -> bool:
        # Does the environment support continuous actions?
        return False
    
    def supports_discrete_actions(self) -> bool:
        # Does the environment support discrete actions?
        return True
    
    def has_render(self, env: EnvBase) -> bool:
        # Does the env have a env.render(mode="rgb_array") or env.render() function?
        return True
    
    def max_steps(self, env: EnvBase) -> int:
        # Maximum number of steps for a rollout during evaluation
        return 300
    
    def group_map(self, env: EnvBase) -> Dict[str, List[str]]:
        # The group map mapping group names to agent names
        # The data in the tensordict will havebe presented this way
        return env.group_map
    
    def action_mask_spec(self, env: EnvBase) -> CompositeSpec:
        # A spec for the action.
        # If provided, must be a CompositeSpec with one (group_name, "action") entry per group.
        return None

    def state_spec(self, env: EnvBase) -> Optional[CompositeSpec]:
        # A spec for the state.
        # If provided, must be a CompositeSpec with one "state" entry
        return None
    
    def info_spec(self, env: EnvBase) -> Optional[CompositeSpec]:
        # A spec for the info.
        # If provided, must be a CompositeSpec with one (group_name, "info") entry per group (this entry can be composite).
        return None
    
    def action_spec(self, env: EnvBase) -> CompositeSpec:
        return env.full_action_spec
    
    def observation_spec(self, env: EnvBase) -> CompositeSpec:
        observation_spec = env.observation_spec.clone()
        for group in self.group_map(env):
            group_obs_spec = observation_spec[group]
            for key in list(group_obs_spec.keys()):
                if key != "observation":
                    del group_obs_spec[key]
        if "state" in observation_spec.keys():
            del observation_spec["state"]
        return observation_spec
    
    @staticmethod
    def env_name() -> str:
        # The name of the environment in the benchmarl/conf/task folder
        return "nats"

