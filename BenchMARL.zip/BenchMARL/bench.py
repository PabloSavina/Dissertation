# flake8: noqa

from benchmarl.algorithms import IqlConfig, MappoConfig, IppoConfig, MaddpgConfig, IddpgConfig, MasacConfig, IsacConfig, QmixConfig, VdnConfig
from benchmarl.environments import PettingZooTask, NATSTask
from benchmarl.benchmark import Benchmark
from benchmarl.experiment import ExperimentConfig
from benchmarl.models.mlp import MlpConfig

experiment_config = ExperimentConfig.get_from_yaml()
experiment_config.max_n_frames = 180_000
experiment_config.max_n_iters = None
experiment_config.loggers = ["wandb"]

task_config = NATSTask.TEST.get_from_yaml()

benchmark = Benchmark(
    algorithm_configs=[
        IppoConfig.get_from_yaml(),
        IqlConfig.get_from_yaml(),
        IddpgConfig.get_from_yaml(),
        MappoConfig.get_from_yaml(),
        MaddpgConfig.get_from_yaml(),
    ],
    tasks=[
        NATSTask.TEST.get_from_yaml(),
    ],
    seeds={0},
    experiment_config=experiment_config,
    model_config=MlpConfig.get_from_yaml(),
    critic_model_config=MlpConfig.get_from_yaml(),
)
benchmark.run_sequential()