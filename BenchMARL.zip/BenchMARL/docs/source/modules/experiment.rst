
benchmarl.experiment
====================

.. currentmodule:: benchmarl.experiment

.. contents:: Contents
    :local:

Experiment
----------

.. autosummary::
   :nosignatures:
   :toctree: ../generated
   :template: autosummary/class.rst

    Experiment
    ExperimentConfig

Callback
--------

.. autosummary::
   :nosignatures:
   :toctree: ../generated
   :template: autosummary/class.rst

    Callback
