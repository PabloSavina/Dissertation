# flake8: noqa

# set PYTHONPATH=%cd%\magpie

from benchmarl.algorithms import IqlConfig, MappoConfig, MaddpgConfig, QmixConfig, IddpgConfig, IppoConfig
from benchmarl.environments import NATSTask
from benchmarl.experiment import Experiment, ExperimentConfig
from benchmarl.models.mlp import MlpConfig

config = ExperimentConfig.get_from_yaml()
config.max_n_frames = 600_000
config.max_n_iters = None
config.loggers = ["wandb"]

experiment = Experiment(
   task=NATSTask.TEST.get_from_yaml(),
   algorithm_config=IppoConfig.get_from_yaml(),
   model_config=MlpConfig.get_from_yaml(),
   critic_model_config=MlpConfig.get_from_yaml(),
   seed=0,
   config=config,
)

experiment.run()

# RENDERING
# We use wandb, which is an open-source Python SDK used for ML experiment management. 